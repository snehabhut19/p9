<?php
$conn = mysqli_connect("localhost","root","mysql123","news-site") or die("connection fail");


?>